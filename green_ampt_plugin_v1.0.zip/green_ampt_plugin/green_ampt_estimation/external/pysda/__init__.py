# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 15:04:19 2022

@author: Charles.Ferguson
"""

__all__ = [
        'sdainterp',
        'sdapoly',
        'sdaprop',
        'sdatab',
        'sdawss'
        ]
        