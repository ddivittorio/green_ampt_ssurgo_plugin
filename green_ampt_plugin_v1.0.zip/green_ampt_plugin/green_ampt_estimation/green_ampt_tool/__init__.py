"""Green-Ampt estimation toolkit."""

from .workflow import run_pipeline  # noqa: F401
