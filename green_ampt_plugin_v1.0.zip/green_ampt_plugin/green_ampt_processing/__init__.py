"""
Green-Ampt Plugin Processing Module
"""

from .green_ampt_provider import GreenAmptProvider
