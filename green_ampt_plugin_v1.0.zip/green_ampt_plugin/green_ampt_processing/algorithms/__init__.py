"""
Green-Ampt Plugin Algorithms
"""

from .green_ampt_ssurgo import GreenAmptSsurgo

__all__ = ["GreenAmptSsurgo"]
